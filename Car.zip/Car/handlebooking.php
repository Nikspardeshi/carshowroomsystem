<?php

if($_SERVER["REQUEST_METHOD"]=="POST"){
    include 'db.php';
    $name = $_POST['name'];
    $carname = $_POST['carname'];
    $email = $_POST['email'];
    $number = $_POST['number'];
    $address = $_POST['address'];


   
            $sql = "INSERT INTO `user` (`name`, `carname`, `email`, `number`, `addresss`) VALUES ('rock', 'discovery', 'rock11@gmail.com', '1234567890', 'jalgaon');";
            $result = mysqli_query($conn, $sql);
            if($result){
            
                header("Location: /Car/index.php");
                exit();
            }
        }
        

    }
    header("Location: /Car/index.php");
}




?>