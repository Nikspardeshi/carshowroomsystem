




<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/css/bootstrap.min.css">
  <title>Car Booking </title>
</head>
<body>
  <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
  <a class="navbar-brand" href="index.php">Olx-Autos</a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>

  <div class="collapse navbar-collapse" id="navbarSupportedContent">
    <ul class="navbar-nav ml-auto">
      <li class="nav-item active">
        <a class="nav-link" href="index.php">Home <span class="sr-only">(current)</span></a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="book.php">Gallery</a>
      </li>
     
        <a class="nav-link" href="admin/login.php">Login</a>
      </li>
      
     
    </ul>
  </div>
</nav>
  <!DOCTYPE html>
<html>
<head>
 <title>Cards</title>
</head>

<style type="text/css">


*{
 margin: 0px;
 padding: 0px;
}
body{
 font-family: arial;
}
.main{

 margin: 1%;
}

.card{
     width: 28%;

     
     display: inline-flex;
     box-shadow: 2px 2px 20px black;
     border-radius: 5px; 
     margin: 2%;
    }

.image img{
  width: 100%;
  border-top-right-radius: 5px;
  border-top-left-radius: 5px;
  

 
 }

.title{
 
  text-align: center;
  padding: 10px;
  
 }

h1{
  font-size: 20px;
  font-family: cursive;
 }

 p{
  font-size: 18px;
  font-family:"Trebuchet MS", Helvetica, sans-serif;
 }

.des{
  padding: 1px;
  text-align: center;
 
  padding-top: 10px;
        border-bottom-right-radius: 5px;
  border-bottom-left-radius: 5px;
}
button{
  margin-top: 40px;
  margin-bottom: 10px;
  background-color: white;
  border: 1px solid black;
  border-radius: 5px;
  padding:10px;
}
button:hover{
  background-color: black;
  color: white;
  transition: .5s;
  cursor: pointer;
}

</style>
<body>

  <div class="main">

  <!--cards -->

  <div class="card">

  <div class="image">
   <img src="image/banner2.jpg">
  </div>
<div class="title">
 <h1>
TOYOTA INNOVA</h1>
</div>
<div class="des">
 <p>
  Model-2019
  <br>Price- 12 lakh to 11 lakh</p>
<button><a href="sign.php">Book now...</a></button>
</div>
</div>
<!--cards -->


<div class="card">

<div class="image">
   <img src="image/banner3.jpg">
</div>
<div class="title">
 <h1>
HONDA AMAZE</h1>
</div>
<div class="des">
 <p>
  Model-2017
  <br>Price- 6 lakh to 5 lakh</p>
<button><a href="sign.php">Book now...</a></button>
</div>
</div>
<!--cards -->





<div class="card">

<div class="image">
   <img src="image/banner7.jpg">
</div>
<div class="title">
 <h1>
TATA SAFARI</h1>
</div>
<div class="des">
 <p>
  Model-2021
  <br>Price- 20 lakh to 18 lakh</p>
<button><a href="sign.php">Book now...</a></button>
</div>
</div>
<!--cards -->


<div class="card">

<div class="image">
   <img src="image/i4.jpg">
</div>
<div class="title">
 <h1>
MARRAZZO</h1>
</div>
<div class="des">
 <p>
  Model-2019
  <br>Price- 15 lakh to 13 lakh</p>
<button><a href="sign.php">Book now...</a></button>
</div>
</div>
<!--cards -->

<div class="card">

<div class="image">
   <img src="image/i7.jpg">
</div>
<div class="title">
 <h1>
TATA NEXON</h1>
</div>
<div class="des">
 <p>
  Model-2020
  <br>Price- 9 lakh to 8lakh</p>
<button><a href="sign.php">Book now...</a></button>
</div>
</div>
<!--cards -->
<div class="card">

<div class="image">
   <img src="image/banner9.jpg">
</div>
<div class="title">
 <h1>
 ALTO 800</h1>
</div>
<div class="des">
 <p>
  Model-2019
  <br>Price- 4 lakh to 3 lakh</p>
<button><a href="sign.php">Book now...</a></button>
</div>
</div>
<!--cards -->

 
<!--cards -->


<div class="card">

<div class="image">
   <img src="image/banner11.jpg">
</div>
<div class="title">
 <h1>
DISCOVERY</h1>
</div>
<div class="des">
 <p>
  Model-2020
  <br>Price- 22 lakh to 21 lakh</p>
<button><a href="sign.php">Book now...</a></button>
</div>
</div>
<!--cards -->





<div class="card">

<div class="image" >
   <img src="image/banner12.jpg" style="padding-bottom: 9px; ">
</div>
<div class="title">
 <h1>
RANGEROVER</h1>
</div>
<div class="des" >
 <p style="padding-top: 6px;">
  Model-2019
  <br>Price- 20 lakh to 19 lakh</p>
<button><a href="sign.php">Book now...</a></button>
</div>
</div>
<!--cards -->

<div class="card">

<div class="image">
   <img src="image/banner6.jpg">
</div>
<div class="title">
 <h1>
SKODA RAPID</h1>
</div>
<div class="des">
 <p>
  Model-2017
  <br>Price- 9 lakh to 7 lakh</p>
<button><a href="sign.php">Book now...</a></button>
</div>
</div>








</div>
</body>
</html>

</body>
</html>