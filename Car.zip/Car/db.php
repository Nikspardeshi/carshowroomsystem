<?php
// Script to connect to the database


$conn = mysqli_connect("localhost", "root", "", "car");

?>