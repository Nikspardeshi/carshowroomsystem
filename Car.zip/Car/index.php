<!DOCTYPE html>
<html>
<head>
	
	<title>Home</title>
	<meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" type="text/css" href="css/style.css">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/css/bootstrap.min.css">
 <style type="text/css">
 .carousel {width: 70%;
            height: 70%;
     display: inline-block;
     box-shadow: 2px 2px 20px black;
     
     margin-left: 15%;}



p{ font-family:Copperplate, Papyrus, fantasy;
    font-size: 25px;
    margin-top: 1%;
    margin-left: 30%;
    font-weight:bold ;
  }

h3{
    font-family:Copperplate, Papyrus, fantasy;
    text-align: center;
  }

</style>
</head>
<body>


<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
  <a class="navbar-brand" href="#">Olx-Autos</a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>

  <div class="collapse navbar-collapse" id="navbarSupportedContent">
    <ul class="navbar-nav ml-auto">
      <li class="nav-item active">
        <a class="nav-link" href="index.php">Home <span class="sr-only">(current)</span></a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="book.php">Gallery</a>
      </li>
      
      <li class="nav-item">
        <a class="nav-link" href="admin/login.php">login</a>
      </li>
      
     
    </ul>
  </div>
</nav>




<div class="card bg-dark text-black">
  <img class="card-img" src="image/banner.jpg" alt="Card image">
  <div class="card-img-overlay">
   
   <p>New Doors Open For You Get Experience Of Luxurious Car's.Come and See what we offer A separate type of company.Affordable High-tech Performance at Low-Tech value Above and Beyond.
   </p>

   <center><h1 style="font-family:Copperplate, Papyrus, fantasy; padding-left: 55%; font-size: 50px ; color: black; font-weight: bold;">...Olx-Autos<br>(Jalgaon)</b></center>
   
  </div>
</div>
<br><br>


<div id="carouselExampleIndicators" class="carousel slide" data-ride="carousel">
  <ol class="carousel-indicators">
    <li data-target="#carouselExampleIndicators" data-slide-to="0" class="active"></li>
    <li data-target="#carouselExampleIndicators" data-slide-to="1"></li>
    <li data-target="#carouselExampleIndicators" data-slide-to="2"></li>
  </ol>
  <div class="carousel-inner">
    <div class="carousel-item active">
      <img class="d-block w-100" src="image/banner4.jpg" alt="First slide">
    </div>
    <div class="carousel-item">
      <img class="d-block w-100" src="image/banner11.jpg" alt="Second slide">
    </div>
    <div class="carousel-item">
      <img class="d-block w-100" src="image/banner7.jpg" alt="Third slide">
    </div>
  </div>
  <a class="carousel-control-prev" href="#carouselExampleIndicators" role="button" data-slide="prev">
    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
    <span class="sr-only">Previous</span>
  </a>
  <a class="carousel-control-next" href="#carouselExampleIndicators" role="button" data-slide="next">
    <span class="carousel-control-next-icon" aria-hidden="true"></span>
    <span class="sr-only">Next</span>
  </a>
</div>
    
  <center><h1>About</h1></center>

<h3>Great Prices. Great Vehicles. Great Service..<br>Book Your Car At Best Price</h3>
  <center><h1>Contact Us</h1></center>
<h3>Conact no- 000000
            <br> Address- Jalgaon(MH)
            <br>  E-mail id- olxautos01@gmail.com</h3>


  






	<script src="https://cdn.jsdelivr.net/npm/jquery@3.5.1/dist/jquery.slim.min.js"></script>
  	<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>
  	<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/js/bootstrap.bundle.min.js"></script>

</body>
</html>