<?php
require('top.inc.php');

if(isset($_GET['del'])){    
	$cmpid=substr(base64_decode($_GET['del']),0,-5);
	$query=mysqli_query($con,"delete from user1 where id='$cmpid'");
	echo "<script>alert('Booking deleted.');</script>";   
	echo "<script>window.location.href='indexx.php'</script>";
}
$sql="select * from user1 order by id desc";
$res=mysqli_query($con,$sql);
?>
<div class="content pb-0">
	<div class="orders">
	   <div class="row">
		  <div class="col-xl-12">
			 <div class="card">
				<div class="card-body">
				   <h4 class="box-title" style="padding-left:50px;">DASHBOARD </h4>
					
				   <div class="table-stats order-table ov-h">
					  <table class="table ">
						  	<thead>
								<tr>
								<th class="serial">#</th>
								<th>Name</th>
								<th>CarName</th>
								<th>Mobile</th>
								<th>Address</th>
								<th>Action</th>
								</tr>
							</thead>
							<?php
                                $rno=mt_rand(10000,99999);  
                                $query=mysqli_query($con,"select * from user1");
                                $cnt=1;
                                while($row=mysqli_fetch_array($query))
                                {    
                                ?>                                                
                                <tr>
                                <td><?php echo $cnt;?></td>
                                <td><?php echo $row['Name'];?></td>
                                <td><?php echo $row['CarName'];?></td>
                                <td><?php echo $row['Mobile'];?></td>
								<td><?php echo $row['Address'];?></td>
                                <td>
                                <a href="indexx.php?del=<?php echo base64_encode($row['id'].$rno);?>" data-toggle="tooltip" data-original-title="Delete" onclick="return confirm('Do you really want to delete?');"> <i class="fa fa-trash txt-danger"></i> </a>
                                </td>
                                </tr>
                                <?php 
                                $cnt++;
                                } 
                            ?>
					  </table>
				   </div>



				</div>
			</div>
		  </div>
	   </div>
	</div>
</div>
<?php
require('footer.inc.php');
?>
