<?php
require('top.inc.php');
isAdmin();
if(isset($_GET['del'])){    
	$cmpid=substr(base64_decode($_GET['del']),0,-5);
	$query=mysqli_query($con,"delete from user where id='$cmpid'");
	echo "<script>alert('Booking record deleted.');</script>";   
	echo "<script>window.location.href='users.php'</script>";
}
$sql="select * from tbl_member order by id desc";
$res=mysqli_query($con,$sql);
?>
<div class="content pb-0">
	<div class="orders">
	   <div class="row">
		  <div class="col-xl-12">
			 <div class="card">
				<div class="card-body" style="padding-left:80px;">
				   <h4 class="box-title">CUSTOMER </h4>
				</div>
				<div class="card-body--">
				   <div class="table-stats order-table ov-h">
					  <table class="table ">
						  	<thead>
								<tr>
								<th class="serial">#</th>
								<th>Name</th>
								<th>Car Name</th>
								<th>Mobile Number</th>
								<th>Address</th>
								<th>Action</th>
								</tr>
							</thead>
							<?php
                                $rno=mt_rand(10000,99999);  
                                $query=mysqli_query($con,"select * from user");
                                $cnt=1;
                                while($row=mysqli_fetch_array($query))
                                {    
                                ?>                                                
                                <tr>
                                <td><?php echo $cnt;?></td>
                                <td><?php echo $row['name'];?></td>
                                <td><?php echo $row['carname'];?></td>
                                <td><?php echo $row['mobile'];?></td>
								<td><?php echo $row['address'];?></td>
                                <td>
                                <a href="users.php?del=<?php echo base64_encode($row['id'].$rno);?>" data-toggle="tooltip" data-original-title="Delete" onclick="return confirm('Do you really want to delete?');"> <i class="fa fa-trash txt-danger"></i> </a>
                                </td>
                                </tr>
                                <?php 
                                $cnt++;
                                } 
                            ?>
					  </table>
				   </div>
				</div>
			 </div>
		  </div>
	   </div>
	</div>
</div>
<?php
require('footer.inc.php');
?>
