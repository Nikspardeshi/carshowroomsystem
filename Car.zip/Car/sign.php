
<?php
session_start();
include('db.php');


if(isset($_POST['submit']))
{

    //Getting Post Values
    $name=$_POST['name']; 
    $carname=$_POST['carname'];
    $num=$_POST['num']; 
    $address=$_POST['address'];
       
    $query=mysqli_query($conn,"INSERT INTO user( name, carname, mobile, address)
     VALUES ('$name','$carname','$num','$address')"); 
    if($query){
        echo "<script>alert('Booking Successfull.');</script>";   
        echo "<script>window.location.href='sign.php'</script>";
    } 
    else{
        echo "<script>alert('Something went wrong. Please try again.');</script>";
    }
}



?>




<!DOCTYPE html>
<html>
  <head>
    <title>Booking Page</title>
    <link rel="stylesheet" type="text/css" href="css/bootstrap.css" />
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/css/bootstrap.min.css">
  </head>
  <style type="text/css">
    
   
  </style>
  
  <body>
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
     <a class="navbar-brand" href="index.php">Olx-Autos</a>
      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="   
        #navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false"  
        aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
    </button>

  <div class="collapse navbar-collapse" id="navbarSupportedContent">
    <ul class="navbar-nav ml-auto">
      <li class="nav-item active">
        <a class="nav-link" href="index.php">Home <span class="sr-only">(current)</span></a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="book.php">Gallery</a>
      </li>
     
        <a class="nav-link" href="admin/login.php">login</a>
      </li>
      
     
    </ul>
  </div>
</nav>




      <form method="post">

    <div class="container">
<div class="row shadow" style="margin: 3em 1em;padding: 2em 1em;">
      <div class="col-md-12 ">
        <div class="panel panel-primary">
          
            <h1 align="center">Booking Form</h1>
          </div>
          
            
             <div class="form-group">
                <label for="name">Name</label>
                <input
                  type="text"
required 
                  class="form-control"
                  id="name"
                  name="name"
                />
              </div>
             

              <div class="form-group">
                <label for="carcode">Car Name</label>

              
                 <select class="form-control" name="carname" placeholder="select carname">
       
      <option>TOYOTA INNOVA</option>
      <option>HONDA AMAZE</option>
      <option>TATA SAFARI</option>
      <option>MARRAZZO</option>
      <option>TATA NEXON</option>
      <option>ALTO 800</option>
      <option>DISCOVERY</option>
      <option>RANGEROVER</option>
      <option>SKODA RAPID</option>
    </select>
                
              </div> 
              

       
              
             
              <div class="form-group">
                <label for="num">Mobile no</label>
                <input
                
                  class="form-control"
                  id="num"
                  name="num"
required 
                />
              </div>


              <div class="form-group">
                <label for="address">Address</label>
                <input
                  type="text"
required 
                  class="form-control"
                  id="address"
                  name="address"
                />
              </div>

              <center><input type="submit" name="submit" value="Submit" /></center>
            </form>
          </div>
          
        </div>
      </div>
    </div>
</div>

</div>
  </body>
</html>
